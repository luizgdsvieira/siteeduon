// Configuração forçada para produção
window.API_BASE_URL = "https://projetoeduon.onrender.com/api";

console.log("🔧 API Base URL configurada:", window.API_BASE_URL);
